from setuptools import setup
setup(name='liang',
      version='0.0.2',
      description='only me',
      url='https://github.com/fengfengxiong123/liang.git',
      author='梁峰',
      author_email='359975715@qq.com',
      license='MIT',
      packages=['liang'],
      zip_safe=False)
